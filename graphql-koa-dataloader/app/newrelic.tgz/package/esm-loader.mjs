/*
 * Copyright 2022 New Relic Corporation. All rights reserved.
 * SPDX-License-Identifier: Apache-2.0
 */

// eslint-disable-next-line n/no-unsupported-features/node-builtins
import { register } from 'node:module'
import subscriptions from './lib/subscriber-configs.js'
import createSubscriberConfigs from './lib/subscribers/create-config.js'
// Exclusions must be regexes.
//
// `/^node:/` excludes Node.js builtins (events, http, fs, etc.) from IITM
// interception. Without this, IITM wraps builtins as Module Namespace
// objects, and CJS packages loaded via the ESM-to-CJS translator (e.g.
// `koa`, which does `require('events')` and then `class Application extends
// Emitter`) get back the wrapped namespace instead of the underlying
// constructor — leading to:
//
//   TypeError: Class extends value [object Module] is not a constructor or null
//
// No subscriber instruments a Node builtin via IITM (builtins use the
// legacy CJS shim path), so excluding them has no effect on coverage —
// including custom instrumentation, which always targets third-party
// packages.
const exclusions = [/@openai\/agents.*/, /^node:/]
const { instrumentations } = createSubscriberConfigs(subscriptions)

register('@apm-js-collab/tracing-hooks/hook.mjs', import.meta.url, {
  data: { instrumentations }
})
register('import-in-the-middle/hook.mjs', import.meta.url, {
  data: { exclude: exclusions }
})
